package com.app.mtgaudiocar.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.webkit.WebViewAssetLoader;

import com.app.mtgaudiocar.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;

import model.ComponentType; // enum já existente
import model.Configuracao;
import model.ConfiguracaoCreateRequest;
import network.ApiClient;
import network.ApiService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MontagemPersonalizadaActivity extends AppCompatActivity {

    private static final String TAG = "MontagemPersonalizada";
    private WebView web3d;

    // === Novos: API + Loading
    private ApiService api;
    private ProgressBar progress; // opcional se existir no layout

    // === Estado atual da montagem (IDs dos componentes selecionados)
    // Preencha esses arrays quando o usuário for escolhendo itens nas telas de lista
    private final List<String> idsSubwoofersSelecionados = new ArrayList<>();
    private final List<String> idsAltoFalantesSelecionados = new ArrayList<>();
    private final List<String> idsModulosSelecionados = new ArrayList<>();
    private final List<String> idsCrossoversSelecionados = new ArrayList<>();

    // Exemplo simples de veículo selecionado (pegue de onde você já guarda isso)
    private String veiculoSelecionado = "Volkswagen Gol";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_montagem_personaliza);

        // Retrofit
        Retrofit retrofit = ApiClient.getClient();
        api = retrofit.create(ApiService.class);

        progress = findViewById(R.id.progress); // pode ser null se não existir no XML

        init3D();

        MaterialButton btnAmp   = findViewById(R.id.btnAmplificador);
        MaterialButton btnAlto  = findViewById(R.id.btnAltoFalante);
        MaterialButton btnSub   = findViewById(R.id.btnSubwoofer);
        MaterialButton btnCross = findViewById(R.id.btnCrossover);

        // Abre a lista genérica já filtrada pelo tipo
        btnAmp.setOnClickListener(v -> openList(ComponentType.MODULO));
        btnAlto.setOnClickListener(v -> openList(ComponentType.ALTOFALANTE));
        btnSub.setOnClickListener(v -> openList(ComponentType.SUBWOOFER));
        btnCross.setOnClickListener(v -> openList(ComponentType.CROSSOVER));

        // === Botão "Salvar projeto" (deve existir no layout)
        View btnSalvarProjeto = findViewById(R.id.btnSalvarProjeto);
        if (btnSalvarProjeto != null) {
            btnSalvarProjeto.setOnClickListener(v -> abrirDialogNomeProjeto());
        }
    }

    /** Abre a ComponentInfoActivity no modo LISTA para o tipo informado */
    private void openList(ComponentType type) {
        Log.d(TAG, "Abrindo lista: " + type);
        Intent i = new Intent(this, ComponentInfoActivity.class);
        i.putExtra(ComponentInfoActivity.EXTRA_TYPE, type);
        startActivity(i);
    }

    // ===========================
    // Fluxo do pop-up + salvamento
    // ===========================
    private void abrirDialogNomeProjeto() {
        // Monta o conteúdo do diálogo em código (TextInputLayout + EditText)
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) getResources().getDisplayMetrics().density * 20;
        container.setPadding(pad, pad, pad, 0);

        TextInputLayout til = new TextInputLayout(this, null, com.google.android.material.R.style.Widget_Material3_TextInputLayout_OutlinedBox);
        til.setHint("Nome do projeto");
        til.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        til.setBoxCornerRadii(20, 20, 20, 20);

        TextInputEditText et = new TextInputEditText(til.getContext());
        et.setId(ViewCompat.generateViewId());
        et.setSingleLine(true);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});
        til.addView(et, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        container.addView(til, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        new MaterialAlertDialogBuilder(this, com.google.android.material.R.style.ThemeOverlay_Material3_MaterialAlertDialog)
                .setTitle("Salvar projeto")
                .setView(container)
                .setNegativeButton("Cancelar", (d, w) -> d.dismiss()) // esquerda
                .setPositiveButton("Salvar", (d, w) -> {
                    String nome = et.getText() != null ? et.getText().toString().trim() : "";
                    if (TextUtils.isEmpty(nome)) {
                        Snackbar.make(findViewById(android.R.id.content), "Informe um nome para o projeto", Snackbar.LENGTH_LONG).show();
                        return;
                    }
                    salvarProjeto(nome);
                }) // direita
                .show();
    }

    private void salvarProjeto(String nomeProjeto) {
        // Monta o corpo do POST baseado no que o front web envia
        ConfiguracaoCreateRequest body = new ConfiguracaoCreateRequest();
        body.setNomeConfiguracao(nomeProjeto);
        body.setVeiculo(veiculoSelecionado);            // pegue do estado real da tela
        body.setRelatorioPdf(null);                     // se houver, preencha aqui
        body.setUsuarioId(obterUsuarioIdLocal());       // se o backend usar token, pode deixar null e enviar Authorization no interceptor

        // IDs selecionados atualmente (preencha essas listas ao longo do fluxo)
        body.setSubwoofers(new ArrayList<>(idsSubwoofersSelecionados));
        body.setAltoFalantes(new ArrayList<>(idsAltoFalantesSelecionados));
        body.setModulos(new ArrayList<>(idsModulosSelecionados));
        body.setCrossovers(new ArrayList<>(idsCrossoversSelecionados));

        toggleLoading(true);
        api.criarConfiguracao(body).enqueue(new Callback<Configuracao>() {
            @Override
            public void onResponse(Call<Configuracao> call, Response<Configuracao> response) {
                toggleLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    Snackbar.make(findViewById(android.R.id.content), "Projeto salvo com sucesso!", Snackbar.LENGTH_LONG).show();

                    // Opcional: navegar para a lista de projetos
                    // startActivity(new Intent(MontagemPersonalizadaActivity.this, ProjetosActivity.class));

                    // Opcional: abrir PDF se backend já gerar relatorioPdf
                    // String pdf = response.body().getRelatorioPdf();
                    // if (!TextUtils.isEmpty(pdf)) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(pdf)));
                } else {
                    Snackbar.make(findViewById(android.R.id.content),
                            "Falha ao salvar (HTTP " + response.code() + ")", Snackbar.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Configuracao> call, Throwable t) {
                toggleLoading(false);
                Log.e(TAG, "Erro ao salvar", t);
                Snackbar.make(findViewById(android.R.id.content),
                        "Erro de rede: " + t.getMessage(), Snackbar.LENGTH_LONG).show();
            }
        });
    }

    private void toggleLoading(boolean show) {
        if (progress != null) progress.setVisibility(show ? View.VISIBLE : View.GONE);
        View btn = findViewById(R.id.btnSalvarProjeto);
        if (btn != null) btn.setEnabled(!show);
    }

    private String obterUsuarioIdLocal() {
        // TODO: se o backend usa token em vez de query/body, retorne null e use Authorization no OkHttp
        return "current-user-id";
    }

    // ===========================
    // Seu código original (3D + placeholder)
    // ===========================
    @SuppressLint("SetJavaScriptEnabled")
    private void init3D() {
        web3d = findViewById(R.id.web3d);

        web3d.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        WebSettings ws = web3d.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web3d.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        WebView.setWebContentsDebuggingEnabled(true);
        web3d.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(android.webkit.ConsoleMessage cm) {
                Log.d("WV", cm.message() + " @" + cm.lineNumber() + " " + cm.sourceId());
                return true;
            }
        });

        web3d.setBackgroundColor(0x00000000);
        web3d.loadUrl("https://appassets.androidplatform.net/assets/Viewer.html");
    }

    // (opcional) ainda dá pra usar o placeholder em outros pontos se quiser
    private void openPlaceholderSheet(String titulo) {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = LayoutInflater.from(this).inflate(R.layout.sheet_placeholder, null, false);
        ((TextView) view.findViewById(R.id.tvSheetTitle)).setText(titulo + " disponíveis");
        ((TextView) view.findViewById(R.id.tvSheetMsg))
                .setText("Nenhum item disponível no momento.\n(Conectaremos ao banco em breve)");
        dialog.setContentView(view);
        dialog.show();
    }

    @Override
    protected void onDestroy() {
        if (web3d != null) {
            web3d.loadUrl("about:blank");
            web3d.destroy();
        }
        super.onDestroy();
    }
}
